import torch
from torchvision import transforms
from PIL import Image

# Define the necessary image transformations
transform = transforms.Compose([
    transforms.Resize((128, 128)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

def predict_student_count(image, model):
    try:
        # Apply transformations
        input_image = transform(image).unsqueeze(0)  # Add batch dimension
        # Predict using the model
        with torch.no_grad():
            output = model(input_image)
        return round(output.item())  # Return the rounded count
    except Exception as e:
        raise ValueError(f"Error processing image: {e}")
