# import torch
# from model import VGG11
# from count import predict_student_count
# from PIL import Image
# import io
# from flask import Flask, request, jsonify
# from flask_pymongo import PyMongo
# from datetime import datetime
# from flask_cors import CORS
# from bson import ObjectId  # Import ObjectId for MongoDB handling

# app = Flask(__name__)
# CORS(app)

# # Load the trained model
# model = VGG11()
# # model.load_state_dict(torch.load("vgg11_student_counter.pth", map_location=torch.device('cpu')))
# model.load_state_dict(torch.load("vgg11_student_counter.pth", map_location=torch.device('cpu'), weights_only=True))

# model.eval()

# # MongoDB connection setup
# app.config["MONGO_URI"] = "mongodb://localhost:27017/predictionsDB"
# mongo = PyMongo(app)


# @app.route('/predict', methods=['POST'])
# def predict():
#     if 'image' not in request.files:
#         return jsonify({'error': 'No image file provided'}), 400

#     file = request.files['image']
#     try:
#         # Read image from request and predict
#         image = Image.open(io.BytesIO(file.read()))
#         count = predict_student_count(image, model)

#         # Save the prediction to MongoDB
#         image_url = "image_placeholder"  # You can store a URL or file path
#         prediction = {
#             'timestamp': datetime.now(),
#             'imageUrl': image_url,
#             'count': count
#         }
#         mongo.db.predictions.insert_one(prediction)

#         return jsonify({'student_count': count})

#     except Exception as e:
#         return jsonify({'error': str(e)}), 500


# # Route to fetch predictions
# @app.route('/api/predictions', methods=['GET'])
# def get_predictions():
#     try:
#         predictions = mongo.db.predictions.find()
#         result = []
#         for prediction in predictions:
#             result.append({
#                 'id': str(prediction['_id']),  # Convert ObjectId to string
#                 'timestamp': prediction['timestamp'],
#                 'imageUrl': prediction['imageUrl'],
#                 'count': prediction['count']
#             })
#         return jsonify(result), 200

#     except Exception as e:
#         return jsonify({'error': str(e)}), 400


# # Route to delete a prediction by its ID
# @app.route('/api/predictions/<prediction_id>', methods=['DELETE'])
# def delete_prediction(prediction_id):
#     try:
#         # Convert the prediction_id to ObjectId
#         object_id = ObjectId(prediction_id)
        
#         # Remove the prediction by its ID
#         result = mongo.db.predictions.delete_one({'_id': object_id})
        
#         if result.deleted_count == 1:
#             return jsonify({'message': 'Prediction deleted successfully'}), 200
#         else:
#             return jsonify({'error': 'Prediction not found'}), 404

#     except Exception as e:
#         return jsonify({'error': str(e)}), 500


# if __name__ == "_main_":
#     app.run(debug=True, port=5001)







import torch
from model import VGG11
from count import predict_student_count
from PIL import Image
import io
from flask import Flask, request, jsonify
from flask_pymongo import PyMongo
from datetime import datetime
from flask_cors import CORS
from bson import ObjectId  # Import ObjectId for MongoDB handling

app = Flask(__name__)
CORS(app)

# Load the trained model
model = VGG11()
model.load_state_dict(torch.load("vgg11_student_counter.pth", map_location=torch.device('cpu')))
model.eval()

# MongoDB connection setup
app.config["MONGO_URI"] = "mongodb://localhost:27017/predictionsDB"
mongo = PyMongo(app)

@app.route('/predict', methods=['POST'])
def predict():
    if 'image' not in request.files:
        return jsonify({'error': 'No image file provided'}), 400

    file = request.files['image']
    try:
        # Read image from request and predict
        image = Image.open(io.BytesIO(file.read()))
        count = predict_student_count(image, model)

        # Save the prediction to MongoDB
        image_url = "image_placeholder"  # Update with actual URL or path logic if needed
        prediction = {
            'timestamp': datetime.now(),
            'imageUrl': image_url,
            'count': count
        }
        mongo.db.predictions.insert_one(prediction)

        return jsonify({'student_count': count})

    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Route to fetch predictions
@app.route('/api/predictions', methods=['GET'])
def get_predictions():
    try:
        predictions = mongo.db.predictions.find()
        result = []
        for prediction in predictions:
            result.append({
                'id': str(prediction['_id']),  # Convert ObjectId to string
                'timestamp': prediction['timestamp'],
                'imageUrl': prediction['imageUrl'],
                'count': prediction['count']
            })
        return jsonify(result), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 400

# Route to delete a prediction by its ID
@app.route('/api/predictions/<prediction_id>', methods=['DELETE'])
def delete_prediction(prediction_id):
    try:
        # Convert the prediction_id to ObjectId
        object_id = ObjectId(prediction_id)
        
        # Remove the prediction by its ID
        result = mongo.db.predictions.delete_one({'_id': object_id})
        
        if result.deleted_count == 1:
            return jsonify({'message': 'Prediction deleted successfully'}), 200
        else:
            return jsonify({'error': 'Prediction not found'}), 404

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True, port=5001)
